<?php 
$sender = 11;
?>
@foreach ($messages as $message)
    <div class="messages">
    @if($message["sender"]!= $sender)
    <div class="message"><img src="/images/profile/pic1.png" width="20" alt="">
      <p class="info">{{ $message["msg"] }}</p>
    </div>
    @endif

    @if($sender==$message["sender"])
    <div class="message me"><img src="/images/profile/pic1.png">
      <p class="info">{{ $message["msg"] }}</p>
    
    </div>
    @endif
    </div>
@endforeach



                         