Hello {{ $client_name }},<br><br>

Welcome to MyNotePaper.<br><br>

Thank You,<br>
MyNotepaper