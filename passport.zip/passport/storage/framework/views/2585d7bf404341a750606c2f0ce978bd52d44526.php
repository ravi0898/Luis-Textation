 <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
    <script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="vendor/bootstrap-datetimepicker/js/moment.js"></script>
    <script src="vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
    <!-- Apex Chart -->
    <script src="vendor/apexchart/apexchart.js"></script>
    
    <!-- Chart piety plugin files -->
    <script src="vendor/peity/jquery.peity.min.js"></script>    
    
    <!-- Dashboard 1 -->
    <script src="js/dashboard/dashboard-1.js"></script>
      <script src="./vendor/dropzone/dist/dropzone.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/deznav-init.js"></script>
    <script src="js/demo.js"></script>
    


<?php /**PATH D:\xampp\htdocs\passport\resources\views/portal/include/js.blade.php ENDPATH**/ ?>