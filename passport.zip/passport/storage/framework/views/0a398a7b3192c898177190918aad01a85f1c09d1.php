<?php 
$sender = 11;
?>
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="messages">
    <?php if($message["sender"]!= $sender): ?>
    <div class="message"><img src="/images/profile/pic1.png" width="20" alt="">
      <p class="info"><?php echo e($message["msg"]); ?></p>
    </div>
    <?php endif; ?>

    <?php if($sender==$message["sender"]): ?>
    <div class="message me"><img src="/images/profile/pic1.png">
      <p class="info"><?php echo e($message["msg"]); ?></p>
    
    </div>
    <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        <?php $__currentLoopData = $admin_chat_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="messages">
                          <?php if($sender==$message["sender"]): ?>
                            <?php  
                            $images = getImageName($image->user_id); 
                            foreach($images as $image) {
                            foreach (json_decode($image->images)as $picture) { ?>
                            <img src="<?php echo asset('/public/files/'.$picture);?>" style="height:120px; width:200px"/>
                            <?php
                            } 
                            }
                            ?> 
                            <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\passport\resources\views/auth/chat_admin.blade.php ENDPATH**/ ?>