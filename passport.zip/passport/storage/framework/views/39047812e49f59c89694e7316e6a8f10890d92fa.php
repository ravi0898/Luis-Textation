Hello <?php echo e($client_name); ?>,<br><br>

Welcome to MyNotePaper.<br><br>

Thank You,<br>
MyNotepaper<?php /**PATH C:\xampp\htdocs\passport\resources\views/welcome_email.blade.php ENDPATH**/ ?>