<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>

                <div class="panel-body">
                     <?php if(session()->has('errorlog')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('errorlog')); ?>

                    </div>
                    <?php endif; ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('login_users_panel')); ?>">
                        <?php echo e(csrf_field()); ?>

                       
                            <label for="mobile_no" class="col-md-4 control-label">Enter Mobile No.</label>
                            <div class="col-md-6">
                                <input id="mobile_no" type="text" class="form-control" name="mobile_no" value="<?php echo e(old('mobile_no')); ?>" required autofocus>
                            </div>
                       

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>

                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\passport\resources\views/auth/login_users.blade.php ENDPATH**/ ?>