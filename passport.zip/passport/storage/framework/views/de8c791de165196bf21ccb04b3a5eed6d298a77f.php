<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
   
   <?php echo $__env->make('portal.include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
 
<body class="h-100 bg-login">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-4">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12 text-center pt-3">
                             
                            <img src="<?php echo e(asset('/images/tlr.png')); ?>" height="60px">
                            
                            </div>    
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Account Login</h4>
                                    <!-- <?php if(session()->has('error')): ?>
                                    <div class="text text-danger">
                                        <?php echo e(session()->get('error')); ?>

                                    </div>
                                     <?php endif; ?> -->
                                    <form action="<?php echo e(url('login_users_panel')); ?>" method="post">
                                         <?php echo e(csrf_field()); ?>

                                        <!-- <div class="form-group">
                                            <label><strong>Mobile Number</strong></label>
                                            <input type="text" class="form-control bdr" name="number" value="" placeholder="xxxxxxxxx" max="10" maxlength="10" onkeypress="return onlyNumberKey(event)" maxlength="10" size="50%" >
                                            <?php if($errors->has('number')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('number')); ?></span>
                                            <?php endif; ?>
                                        </div> -->

                                        <div class="form-group">
                                            <label><strong>Email</strong></label>
                                            <input type="text" class="form-control bdr" name="email" value="" placeholder="Enter your email here">
                                            <?php if($errors->has('email')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group">
                                            <label><strong>Password</strong></label>
                                            <input type="password" class="form-control bdr" name="password" value="" placeholder="Enter your password here" >
                                            <?php if($errors->has('password')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container -->
    <!-- Common JS -->
    <?php echo $__env->make('portal.include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <script>
    function onlyNumberKey(evt) {
          
        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    }
</script>
<script>
    function detailssubmit() {
        alert("Your details were Submitted");
    }
</script>
</body>

</html><?php /**PATH C:\xampp\htdocs\passport\resources\views/index.blade.php ENDPATH**/ ?>