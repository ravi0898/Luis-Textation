<?php 
$sender = 11;
?>
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="messages">
    <?php if($message["sender"]!= $sender): ?>
    <div class="message"><img src="/images/profile/pic1.png" width="20" alt="">
      <p class="info"><?php echo e($message["msg"]); ?></p>
    </div>
    <?php endif; ?>

    <?php if($sender==$message["sender"]): ?>
    <div class="message me"><img src="/images/profile/pic1.png">
      <p class="info"><?php echo e($message["msg"]); ?></p>
    
    </div>
    <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                         <?php /**PATH C:\xampp\htdocs\passport\resources\views/auth/chat_admin.blade.php ENDPATH**/ ?>