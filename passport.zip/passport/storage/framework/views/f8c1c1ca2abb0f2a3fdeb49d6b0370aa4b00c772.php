
    <div class="card-header border-0 pb-0 d-sm-flex d-block">
        <div>
        <h4> <span class="more"><?php echo e($ticket_result['subject']); ?></span> </h4>
        </div>
        <div class="float-right position-fixed set-pos">
        <a href="<?php echo e(route('ticket.reply', ['id' => $id_ticket, 'user_id' => $sender])); ?>" type="button" class="btn btn-primary">Reply <i class="fa fa-reply"></i></a>
        </div>      
    </div>
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card-body">
<?php if($message["sender"]!= $sender): ?>
<div class="Administrator">
<div class="row">
<div class="col-lg-4">
<div class="row">

<div class="col-md-3">
<img class="w-100" src="/images/avatar/1.png" alt="">
</div>

<div class="col-md-9">
<div class="bdr-l">  
<h5>Luis Rendon</h5>
<small class="text-black">Admin</small>
</div>
</div>
</div>
</div>
<div class="col-lg-8">
<div class="row">
<div class="col-xl-12 text-success">
Posted On : <?php echo e($message["created_at"]); ?>

</div>
<div class="col-xl-12"><?php echo e($message["msg"]); ?>

</div>
<div class="col-xl-12 footer-chat">
Thanks
<small>  Website </small>
</div>      
</div>
</div>      

</div><!---row-->
</div><!---Administrator--->
<?php endif; ?>

<?php if($sender==$message["sender"]): ?>
<div class="userss mt-4">
<div class="row">
<div class="col-lg-8">
<div class="row">
<div class="col-xl-12 text-success">
Posted On : <?php echo e($message["created_at"]); ?>

</div>
<div class="col-xl-12"><?php echo e($message["msg"]); ?>


</div>
<div class="col-xl-12 footer-chat">
Thanks
<small><?php echo e($client_name); ?></small>

</div>
<div class="col-xl-12 footer-chat text-black"> 
<a href="#" class="text-danger"> <i class="fa fa-paperclip"></i> 3 file attached</a> 
<div class="attachment mt-3">
<!-- <a href="images/profile/2.jpg"><img class="small-img img-size" src="images/profile/2.jpg"></a>
<a href="images/profile/4.jpg"><img class="small-img img-size" src="images/profile/4.jpg"></a> -->

<div id="lightgallery" class="attachment">
<a href="images/big/img1.jpg" data-exthumbimage="images/big/img1.jpg" data-src="images/big/img1.jpg" class="">
<img src="/images/big/img1.jpg" class="img-size">
</a>

<a href="images/big/img2.jpg" data-exthumbimage="images/big/img2.jpg" data-src="images/big/img2.jpg" class="">
<img src="/images/big/img2.jpg" class="img-size">
</a>

<a href="images/big/img3.jpg" data-exthumbimage="images/big/img3.jpg" data-src="images/big/img3.jpg" class="">
<img src="/images/big/img3.jpg" class="img-size">
</a>
</div>
</div>
</div>
</div>
</div> 
<div class="col-lg-4">
<div class="row">
<div class="col-md-9">
<div class="bdr-r text-right">  
<h5><?php echo e($client_name); ?></h5>
<small class="text-black">User</small>
</div>
</div>
<div class="col-md-3">
<img class="w-100" src="images/avatar/1.png" alt="">
</div>
</div>
</div>      
</div><!---row-->
</div><!---userss-->
<?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                       


                  



<style type="text/css">
.morecontent span {
display: none;
}
.morelink {
display: block;
color: red;
margin-left: 722px;
margin-top: -22px;
}
</style>


<!--  Read more  -->
<script>
$(document).ready(function() {

// Configure/customize these variables.
var showChar = 80;  // How many characters are shown by default
var ellipsestext = "...";
var moretext = "View more >>";
var lesstext = "<< View less";


$('.more').each(function() {
var content = $(this).html();

if(content.length > showChar) {

var c = content.substr(0, showChar);
var h = content.substr(showChar, content.length - showChar);

var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

$(this).html(html);
}

});

$(".morelink").click(function(){
if($(this).hasClass("less")) {
$(this).removeClass("less");
$(this).html(moretext);
} else {
$(this).addClass("less");
$(this).html(lesstext);
}
$(this).parent().prev().toggle();
$(this).prev().toggle();
return false;
});

});
</script>

<?php /**PATH C:\xampp\htdocs\passport\resources\views/chat_user.blade.php ENDPATH**/ ?>