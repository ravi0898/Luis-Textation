<?php
use App\Product;
use App\Chatadmin;
use App\Reply;


if (! function_exists('getUserName')) {
    function getUserName($id){
       $username = Product::where('data_id', $id)->first();
       $client_name = $username->client_name;
        return $client_name;
    }
}


if (! function_exists('getImageName')) {
    function getImageName($id){
       //$images = Chatadmin::where('user_id', $id)->get();
       $images = Chatadmin::select('images')->where('user_id', $id)->get();
       // echo "<pre>"; print_r($images); exit;
       return $images;
        }
    }


if (! function_exists('getUserImageName')) {
    function getUserImageName($id){
        //$images = Chatadmin::where('user_id', $id)->get();
        $images = Reply::select('images')->where('user_id', $id)->get();
        // echo "<pre>"; print_r($images); exit;
        return $images;
        }
    }    

